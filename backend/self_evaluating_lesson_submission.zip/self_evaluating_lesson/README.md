# Self-Evaluating Lesson Content Generator

A Python/FastAPI demonstration that generates a beginner-friendly RAG lesson, evaluates it against six criteria, improves failed sections, retries up to two times, and stores evaluation history in SQLite.

## Features

- Topic input through a simple browser interface and `POST /generate`.
- Six fixed evaluation criteria:
  1. Accuracy and grounding
  2. Beginner-friendly language
  3. Teaches by example
  4. No unexplained jargon
  5. Covers key points
  6. Coherent teaching flow
- One initial evaluation plus up to two retries.
- Rule-based lesson improvement for the RAG demonstration topic.
- SQLite evaluation history and recurring-failure hints.
- Experimental arXiv paper retrieval and lexical evidence comparison modules (not treated as proof of factual accuracy).
- `GET /history` to inspect saved evaluations.
- `GET /health` to check the API.

## Important limitations

This deadline-ready version is a rule-based prototype, not a connected generative AI model. The built-in generator currently supports the Introduction to RAG demonstration topic. The evaluator checks simple structural rules; it does not deeply assess meaning. The arXiv source reader and evidence checker are experimental helpers; lexical overlap is not semantic verification and they are not used to automatically approve lessons.

Accuracy remains `PENDING` by default. The optional human-verification checkbox is a user attestation, not independent verification by the software. Never treat keyword overlap as proof of correctness.

## Setup on Windows PowerShell

1. Open a terminal in the `backend` folder.
2. Create a virtual environment if you do not already have one:

   ```powershell
   py -m venv venv
   ```

3. Activate it:

   ```powershell
   .\venv\Scripts\Activate.ps1
   ```

4. Install dependencies:

   ```powershell
   python -m pip install -r requirements.txt
   ```

5. Start the server:

   ```powershell
   python -m uvicorn main:app --reload
   ```

6. Open `http://127.0.0.1:8000` in your browser.
7. API documentation is available at `http://127.0.0.1:8000/docs`.

## API endpoints

- `GET /` — browser interface
- `GET /health` — health check
- `POST /generate` — generate/evaluate/improve a lesson
- `GET /history` — saved evaluation records

Example request body:

```json
{
  "topic": "Introduction to RAG",
  "human_verified": false
}
```

## Project structure

```text
self_evaluating_lesson_submission/
├── backend/
│   ├── agent.py
│   ├── evaluator.py
│   ├── improver.py
│   ├── lesson_generator.py
│   ├── learning.py
│   ├── memory.py
│   ├── main.py
│   ├── requirements.txt
│   ├── .gitignore
│   └── .env.example
└── README.md
```

The SQLite database is created automatically in the backend folder when the application runs.

## Security

Do not upload `.env`, API keys, or the virtual environment. If a real API key was included in a shared ZIP, revoke or rotate it.
